[![Build status](https://ci.appveyor.com/api/projects/status/r0ge94ykde5k2yc3/branch/master?svg=true)](https://ci.appveyor.com/project/fabiendibot/cmicrosoftupdate/branch/master)

# cMicrosoftUpdate
PowerShell Desired State Configuration resource for WSUS